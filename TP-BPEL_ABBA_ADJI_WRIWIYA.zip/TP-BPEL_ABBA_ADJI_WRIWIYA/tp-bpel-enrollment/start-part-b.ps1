param(
    [string]$BrokerCmd = ""
)

$activate = Join-Path $PSScriptRoot "..\..\activate-tp.ps1"

if (-not $BrokerCmd) {
    $candidates = @(
        (Join-Path $PSScriptRoot "..\..\tools\artemis-broker\bin\artemis.cmd"),
        (Join-Path $HOME "artemis-broker\bin\artemis.cmd")
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $BrokerCmd = (Resolve-Path $c).Path; break }
    }
    if (-not $BrokerCmd -and (Get-Command artemis.cmd -ErrorAction SilentlyContinue)) {
        $BrokerCmd = "artemis.cmd"
    }
}

if ($BrokerCmd) {
    foreach ($t in @("EnrollmentRequested", "StudentRegistered", "PaymentDecided", "EnrollmentCompleted")) {
        & $BrokerCmd address create --name $t --multicast --user admin --password admin 2>$null
    }
}

if (-not (Test-Path (Join-Path $PSScriptRoot "services/university-service/target/university-service-1.0-SNAPSHOT-classes.jar"))) {
    Push-Location $PSScriptRoot
    if (Test-Path $activate) { . $activate }
    mvn clean install -DskipTests
    Pop-Location
}

$adapters = @(
    "university-event-adapter",
    "bank-event-adapter",
    "residence-event-adapter",
    "transport-event-adapter"
)
foreach ($ad in $adapters) {
    if (Test-Path $activate) {
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$activate'; Set-Location '$PSScriptRoot'; mvn -pl choreography/$ad spring-boot:run"
    } else {
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PSScriptRoot'; mvn -pl choreography/$ad spring-boot:run"
    }
}
Write-Host "All 4 choreography adapters launched." -ForegroundColor Green
