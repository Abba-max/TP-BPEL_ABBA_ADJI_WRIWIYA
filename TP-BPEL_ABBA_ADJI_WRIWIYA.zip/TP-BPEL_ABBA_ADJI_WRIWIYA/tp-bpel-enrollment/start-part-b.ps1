param(
    [string]$BrokerCmd = ""
)

$activate = Join-Path $PSScriptRoot "..\..\activate-tp.ps1"
if (Test-Path $activate) { . $activate }

$BaseArtemis = ""
$baseCand = Join-Path $PSScriptRoot "..\..\tools\artemis-2.33\bin\artemis.cmd"
if (Test-Path $baseCand) {
    $BaseArtemis = (Resolve-Path $baseCand).Path
} elseif (Get-Command artemis.cmd -ErrorAction SilentlyContinue) {
    $BaseArtemis = (Get-Command artemis.cmd).Source
}

$BrokerDir = ""
$toolsBroker = Join-Path $PSScriptRoot "..\..\tools\artemis-broker"
$homeBroker = Join-Path $HOME "artemis-broker"
if (Test-Path $toolsBroker) {
    $BrokerDir = (Resolve-Path $toolsBroker).Path
} elseif (Test-Path $homeBroker) {
    $BrokerDir = (Resolve-Path $homeBroker).Path
} elseif ($BaseArtemis) {
    $BrokerDir = $toolsBroker
    & $BaseArtemis create $BrokerDir --user admin --password admin --allow-anonymous
    $BrokerDir = (Resolve-Path $BrokerDir).Path
}

if (-not $BrokerCmd -and $BrokerDir) {
    $candCmd = Join-Path $BrokerDir "bin\artemis.cmd"
    if (Test-Path $candCmd) { $BrokerCmd = $candCmd }
}

# Start broker automatically in a new window if port 61616 is not open yet
$portOpen = $false
try {
    $tcp = New-Object System.Net.Sockets.TcpClient
    $tcp.Connect("127.0.0.1", 61616)
    $portOpen = $true
    $tcp.Close()
} catch {}

if (-not $portOpen -and $BrokerCmd) {
    Write-Host "Starting ActiveMQ Artemis broker..." -ForegroundColor Cyan
    if (Test-Path $activate) {
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$activate'; & '$BrokerCmd' run"
    } else {
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$BrokerCmd' run"
    }
    Start-Sleep -Seconds 8
}

if ($BrokerCmd) {
    foreach ($t in @("EnrollmentRequested", "StudentRegistered", "PaymentDecided", "EnrollmentCompleted")) {
        & $BrokerCmd address create --name $t --multicast --user admin --password admin 2>$null
    }
}

if (-not (Test-Path (Join-Path $PSScriptRoot "services/university-service/target/university-service-1.0-SNAPSHOT-classes.jar"))) {
    Push-Location $PSScriptRoot
    mvn clean install -DskipTests
    Pop-Location
}

$adapters = @(
    "university-event-adapter",
    "bank-event-adapter",
    "residence-event-adapter",
    "transport-event-adapter"
)
foreach ($ad in $adapters) {
    if (Test-Path $activate) {
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$activate'; Set-Location '$PSScriptRoot'; mvn -pl choreography/$ad spring-boot:run"
    } else {
        Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PSScriptRoot'; mvn -pl choreography/$ad spring-boot:run"
    }
}
Write-Host "Broker and all 4 choreography adapters are running." -ForegroundColor Green
