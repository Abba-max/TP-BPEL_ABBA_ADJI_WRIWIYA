param(
    [string]$TomcatHome = ""
)

. (Join-Path $PSScriptRoot "activate-tp.ps1")

if (-not $TomcatHome) {
    $TomcatHome = if ($env:TOMCAT_HOME) { $env:TOMCAT_HOME } else { $env:CATALINA_HOME }
}
if (-not $TomcatHome -or -not (Test-Path $TomcatHome)) {
    Write-Error "Set TOMCAT_HOME / CATALINA_HOME or pass -TomcatHome <path-to-tomcat9>"
    exit 1
}

Push-Location $PSScriptRoot
mvn clean install
if ($LASTEXITCODE -ne 0) { Pop-Location; exit $LASTEXITCODE }

$webapps = Join-Path $TomcatHome "webapps"
$services = @("university-service", "bank-service", "residence-service", "transport-service")
foreach ($svc in $services) {
    Copy-Item "services/$svc/target/$svc.war" -Destination $webapps -Force
}

$odeProc = Join-Path $webapps "ode/WEB-INF/processes/enrollment"
Remove-Item "$odeProc*" -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $odeProc -Force | Out-Null
Copy-Item "bpel-orchestrator/*" -Destination $odeProc -Recurse -Force
foreach ($svc in $services) {
    Copy-Item "services/$svc/src/main/resources/*.wsdl" -Destination $odeProc -Force
}

Pop-Location
Write-Host "Part A built and deployed to $TomcatHome" -ForegroundColor Green
