#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/../../activate-tp.sh" ]; then
  source "$SCRIPT_DIR/../../activate-tp.sh"
fi

ARTEMIS_CMD=""
if [ -x "$HOME/artemis-broker/bin/artemis" ]; then
  ARTEMIS_CMD="$HOME/artemis-broker/bin/artemis"
elif [ -x "$SCRIPT_DIR/../../tools/artemis-broker/bin/artemis" ]; then
  ARTEMIS_CMD="$SCRIPT_DIR/../../tools/artemis-broker/bin/artemis"
elif command -v artemis >/dev/null 2>&1; then
  ARTEMIS_CMD="artemis"
fi

if [ -n "$ARTEMIS_CMD" ]; then
  for topic in EnrollmentRequested StudentRegistered PaymentDecided EnrollmentCompleted; do
    "$ARTEMIS_CMD" address create --name "$topic" --multicast --user admin --password admin >/dev/null 2>&1 || true
  done
fi

cd "$SCRIPT_DIR"
if [ ! -f "services/university-service/target/university-service-1.0-SNAPSHOT-classes.jar" ]; then
  mvn clean install -DskipTests
fi

for ad in university-event-adapter bank-event-adapter residence-event-adapter transport-event-adapter; do
  mvn -pl "choreography/$ad" spring-boot:run &
done
echo "All 4 Spring Boot choreography adapters started. Press Ctrl+C to stop."
wait
