#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/../../activate-tp.sh" ]; then
  source "$SCRIPT_DIR/../../activate-tp.sh"
fi

# Locate base artemis binary if needed to create broker
BASE_ARTEMIS=""
if [ -x "$SCRIPT_DIR/../../tools/artemis-2.33/bin/artemis" ]; then
  BASE_ARTEMIS="$SCRIPT_DIR/../../tools/artemis-2.33/bin/artemis"
elif command -v artemis >/dev/null 2>&1; then
  BASE_ARTEMIS="$(command -v artemis)"
elif [ -n "$ARTEMIS_HOME" ] && [ -x "$ARTEMIS_HOME/bin/artemis" ]; then
  BASE_ARTEMIS="$ARTEMIS_HOME/bin/artemis"
fi

# Locate or create broker instance
BROKER_DIR=""
if [ -d "$SCRIPT_DIR/../../tools/artemis-broker" ]; then
  BROKER_DIR="$(cd "$SCRIPT_DIR/../../tools/artemis-broker" && pwd)"
elif [ -d "$HOME/artemis-broker" ]; then
  BROKER_DIR="$HOME/artemis-broker"
elif [ -n "$BASE_ARTEMIS" ]; then
  BROKER_DIR="$HOME/artemis-broker"
  "$BASE_ARTEMIS" create "$BROKER_DIR" --user admin --password admin --allow-anonymous
fi

ARTEMIS_CMD=""
if [ -n "$BROKER_DIR" ] && [ -x "$BROKER_DIR/bin/artemis" ]; then
  ARTEMIS_CMD="$BROKER_DIR/bin/artemis"
elif [ -n "$BASE_ARTEMIS" ]; then
  ARTEMIS_CMD="$BASE_ARTEMIS"
fi

# Start broker automatically if port 61616 is not open
if ! (echo > /dev/tcp/localhost/61616) >/dev/null 2>&1; then
  if [ -n "$BROKER_DIR" ] && [ -x "$BROKER_DIR/bin/artemis-service" ]; then
    "$BROKER_DIR/bin/artemis-service" start
    sleep 5
  elif [ -n "$ARTEMIS_CMD" ]; then
    "$ARTEMIS_CMD" run &
    sleep 6
  fi
fi

if [ -n "$ARTEMIS_CMD" ]; then
  for topic in EnrollmentRequested StudentRegistered PaymentDecided EnrollmentCompleted; do
    "$ARTEMIS_CMD" address create --name "$topic" --multicast --user admin --password admin >/dev/null 2>&1 || true
  done
fi

cd "$SCRIPT_DIR"
if [ ! -f "services/university-service/target/university-service-1.0-SNAPSHOT-classes.jar" ]; then
  mvn clean install -DskipTests
fi

for ad in university-event-adapter bank-event-adapter residence-event-adapter transport-event-adapter; do
  mvn -pl "choreography/$ad" spring-boot:run &
done
echo "All 4 Spring Boot choreography adapters started. Press Ctrl+C to stop."
wait
