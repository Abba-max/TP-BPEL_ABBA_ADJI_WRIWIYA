#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/../../activate-tp.sh" ]; then
  source "$SCRIPT_DIR/../../activate-tp.sh"
fi

TOMCAT_DIR="${TOMCAT_HOME:-${CATALINA_HOME:-}}"
if [ -z "$TOMCAT_DIR" ] && [ -d "$HOME/opt/tomcat9" ]; then
  TOMCAT_DIR="$HOME/opt/tomcat9"
elif [ -z "$TOMCAT_DIR" ] && [ -d "$SCRIPT_DIR/../../tools/tomcat-9" ]; then
  TOMCAT_DIR="$(cd "$SCRIPT_DIR/../../tools/tomcat-9" && pwd)"
fi

if [ -z "$TOMCAT_DIR" ] || [ ! -d "$TOMCAT_DIR" ]; then
  echo "Error: Please set TOMCAT_HOME or CATALINA_HOME to your Tomcat 9 directory." >&2
  exit 1
fi

cd "$SCRIPT_DIR"
mvn clean install

for svc in university-service bank-service residence-service transport-service; do
  cp "services/$svc/target/${svc}.war" "$TOMCAT_DIR/webapps/"
done

ODE_PROC="$TOMCAT_DIR/webapps/ode/WEB-INF/processes/enrollment"
rm -rf "${ODE_PROC}" "${ODE_PROC}.deployed"
mkdir -p "$ODE_PROC"
cp -r bpel-orchestrator/* "$ODE_PROC/"
for svc in university-service bank-service residence-service transport-service; do
  cp "services/$svc/src/main/resources/"*.wsdl "$ODE_PROC/"
done

echo "Part A built and deployed to $TOMCAT_DIR"
