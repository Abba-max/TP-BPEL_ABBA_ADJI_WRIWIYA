#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCENARIO="${1:-nominal}"

ARTEMIS_CMD=""
if [ -x "$HOME/artemis-broker/bin/artemis" ]; then
  ARTEMIS_CMD="$HOME/artemis-broker/bin/artemis"
elif [ -x "$SCRIPT_DIR/../../tools/artemis-broker/bin/artemis" ]; then
  ARTEMIS_CMD="$SCRIPT_DIR/../../tools/artemis-broker/bin/artemis"
elif command -v artemis >/dev/null 2>&1; then
  ARTEMIS_CMD="artemis"
fi

if [ "$SCENARIO" = "refused" ]; then
  MSG='{"correlationId":"enr-002","type":"EnrollmentRequested","data":{"student":{"name":"Bob","program":"ISI4"},"amount":"900000"}}'
else
  MSG='{"correlationId":"enr-001","type":"EnrollmentRequested","data":{"student":{"name":"Alice","program":"ISI4"},"amount":"350000"}}'
fi

if [ -n "$ARTEMIS_CMD" ]; then
  "$ARTEMIS_CMD" producer --destination topic://EnrollmentRequested --user admin --password admin --message-count 1 --message "$MSG"
else
  echo "Error: Could not find ~/artemis-broker/bin/artemis or artemis on PATH." >&2
  exit 1
fi
