# Environment activation script - uses local tools/ if present, otherwise falls back to system environment
$SearchRoots = @($PSScriptRoot, (Join-Path $PSScriptRoot "..\.."))

foreach ($root in $SearchRoots) {
    $jdkCand = Join-Path $root "tools\jdk-11"
    if (Test-Path (Join-Path $jdkCand "bin\java.exe")) {
        $env:JAVA_HOME = (Resolve-Path $jdkCand).Path
        $env:Path = "$env:JAVA_HOME\bin;$env:Path"
        break
    }
}

foreach ($root in $SearchRoots) {
    $mvnCand = Join-Path $root "tools\maven-3.9"
    if (Test-Path (Join-Path $mvnCand "bin\mvn.cmd")) {
        $env:M2_HOME = (Resolve-Path $mvnCand).Path
        $env:Path = "$env:M2_HOME\bin;$env:Path"
        break
    }
}

foreach ($root in $SearchRoots) {
    $tomCand = Join-Path $root "tools\tomcat-9"
    if (Test-Path (Join-Path $tomCand "bin\catalina.bat")) {
        $env:CATALINA_HOME = (Resolve-Path $tomCand).Path
        $env:TOMCAT_HOME = $env:CATALINA_HOME
        break
    }
}
if (-not $env:CATALINA_HOME -and $env:TOMCAT_HOME) {
    $env:CATALINA_HOME = $env:TOMCAT_HOME
}

foreach ($root in $SearchRoots) {
    $artBrokerCand = Join-Path $root "tools\artemis-broker\bin"
    $artBaseCand   = Join-Path $root "tools\artemis-2.33\bin"
    if (Test-Path (Join-Path $artBrokerCand "artemis.cmd")) {
        $env:Path = "$((Resolve-Path $artBrokerCand).Path);$env:Path"
    }
    if (Test-Path (Join-Path $artBaseCand "artemis.cmd")) {
        $env:ARTEMIS_HOME = (Resolve-Path (Join-Path $root "tools\artemis-2.33")).Path
        $env:Path = "$((Resolve-Path $artBaseCand).Path);$env:Path"
        break
    }
}
if (Test-Path (Join-Path $HOME "artemis-broker\bin")) {
    $env:Path = "$(Join-Path $HOME 'artemis-broker\bin');$env:Path"
}

Write-Host "TP Environment Ready:" -ForegroundColor Green
java -version
mvn -version
