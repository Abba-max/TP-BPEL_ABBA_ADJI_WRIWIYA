param(
    [ValidateSet("nominal", "refused")]
    [string]$Scenario = "nominal"
)

$BrokerCmd = ""
$candidates = @(
    (Join-Path $PSScriptRoot "..\..\tools\artemis-broker\bin\artemis.cmd"),
    (Join-Path $HOME "artemis-broker\bin\artemis.cmd")
)
foreach ($c in $candidates) {
    if (Test-Path $c) { $BrokerCmd = (Resolve-Path $c).Path; break }
}
if (-not $BrokerCmd -and (Get-Command artemis.cmd -ErrorAction SilentlyContinue)) {
    $BrokerCmd = "artemis.cmd"
}

if (-not $BrokerCmd) {
    Write-Error "Could not find artemis-broker/bin/artemis.cmd"
    exit 1
}

if ($Scenario -eq "refused") {
    $msg = '{"correlationId":"enr-002","type":"EnrollmentRequested","data":{"student":{"name":"Bob","program":"ISI4"},"amount":"900000"}}'
} else {
    $msg = '{"correlationId":"enr-001","type":"EnrollmentRequested","data":{"student":{"name":"Alice","program":"ISI4"},"amount":"350000"}}'
}

& $BrokerCmd producer --destination topic://EnrollmentRequested --user admin --password admin --message-count 1 --message $msg
