package bpel.tp.transport;

import javax.jws.WebService;
import java.util.UUID;

// Implementing transit pass activation service
@WebService(
    serviceName       = "TransportService",
    portName          = "TransportPort",
    endpointInterface = "bpel.tp.transport.TransportPT",
    targetNamespace   = "http://tp.bpel/transport/",
    wsdlLocation      = "WEB-INF/wsdl/transport.wsdl"
)
public class TransportServiceImpl implements TransportPT {
    @Override
    public ActivateResponse activatePass(ActivateRequest req) {
        ActivateResponse r = new ActivateResponse();
        r.setPassId("PASS-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase());
        return r;
    }
}
