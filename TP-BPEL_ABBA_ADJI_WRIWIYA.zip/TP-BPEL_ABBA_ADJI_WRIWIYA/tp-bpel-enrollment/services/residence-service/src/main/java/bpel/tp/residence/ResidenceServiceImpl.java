package bpel.tp.residence;

import javax.jws.WebService;
import java.util.concurrent.atomic.AtomicInteger;

// Implementing room allocation service
@WebService(
    serviceName       = "ResidenceService",
    portName          = "ResidencePort",
    endpointInterface = "bpel.tp.residence.ResidencePT",
    targetNamespace   = "http://tp.bpel/residence/",
    wsdlLocation      = "WEB-INF/wsdl/residence.wsdl"
)
public class ResidenceServiceImpl implements ResidencePT {
    private static final AtomicInteger ROOM_SEQ = new AtomicInteger(100);

    @Override
    public AssignResponse assignRoom(AssignRequest req) {
        AssignResponse r = new AssignResponse();
        r.setRoomNumber("B-" + ROOM_SEQ.incrementAndGet());
        return r;
    }
}
