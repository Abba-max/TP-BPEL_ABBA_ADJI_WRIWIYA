package bpel.tp.university;

import javax.jws.WebService;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

// Implementing student registration and compensation cancellation
@WebService(
    serviceName       = "UniversityService",
    portName          = "UniversityPort",
    endpointInterface = "bpel.tp.university.UniversityPT",
    targetNamespace   = "http://tp.bpel/university/",
    wsdlLocation      = "WEB-INF/wsdl/university.wsdl"
)
public class UniversityServiceImpl implements UniversityPT {
    private static final Map<String, String> REGISTRY = new ConcurrentHashMap<>();

    @Override
    public RegisterResponse register(RegisterRequest req) {
        String id = "STU-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        String name = req.getStudent() != null ? req.getStudent().getName() : "Unknown";
        REGISTRY.put(id, "ACTIVE:" + name);
        System.out.println("[University] Registered " + id + " (" + name + ")");
        RegisterResponse r = new RegisterResponse();
        r.setStudentId(id);
        return r;
    }

    @Override
    public void cancel(CancelRequest req) {
        String id = req.getStudentId();
        if (id != null) {
            REGISTRY.put(id, "CANCELLED");
            System.out.println("[University] Cancelled registration for " + id);
        }
    }
}
