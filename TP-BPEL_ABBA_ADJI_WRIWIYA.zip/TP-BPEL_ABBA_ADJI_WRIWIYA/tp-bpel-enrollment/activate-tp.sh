#!/usr/bin/env bash
# Environment activation script - uses local tools/ if present, otherwise falls back to system environment
SCRIPT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

for root in "$SCRIPT_ROOT" "$SCRIPT_ROOT/../.."; do
  if [ -d "$root/tools/jdk-11/Contents/Home/bin" ]; then
    export JAVA_HOME="$(cd "$root/tools/jdk-11/Contents/Home" && pwd)"
    export PATH="$JAVA_HOME/bin:$PATH"
    break
  elif [ -d "$root/tools/jdk-11/bin" ]; then
    export JAVA_HOME="$(cd "$root/tools/jdk-11" && pwd)"
    export PATH="$JAVA_HOME/bin:$PATH"
    break
  fi
done

for root in "$SCRIPT_ROOT" "$SCRIPT_ROOT/../.."; do
  if [ -d "$root/tools/maven-3.9/bin" ]; then
    export M2_HOME="$(cd "$root/tools/maven-3.9" && pwd)"
    export PATH="$M2_HOME/bin:$PATH"
    break
  fi
done

for root in "$SCRIPT_ROOT" "$SCRIPT_ROOT/../.."; do
  if [ -d "$root/tools/tomcat-9/bin" ]; then
    export CATALINA_HOME="$(cd "$root/tools/tomcat-9" && pwd)"
    export TOMCAT_HOME="$CATALINA_HOME"
    break
  fi
done
if [ -z "$CATALINA_HOME" ] && [ -n "$TOMCAT_HOME" ]; then
  export CATALINA_HOME="$TOMCAT_HOME"
elif [ -z "$CATALINA_HOME" ] && [ -d "$HOME/opt/tomcat9" ]; then
  export CATALINA_HOME="$HOME/opt/tomcat9"
  export TOMCAT_HOME="$CATALINA_HOME"
fi

for root in "$SCRIPT_ROOT" "$SCRIPT_ROOT/../.."; do
  if [ -d "$root/tools/artemis-broker/bin" ]; then
    export PATH="$(cd "$root/tools/artemis-broker/bin" && pwd):$PATH"
  fi
  if [ -d "$root/tools/artemis-2.33/bin" ]; then
    export ARTEMIS_HOME="$(cd "$root/tools/artemis-2.33" && pwd)"
    export PATH="$ARTEMIS_HOME/bin:$PATH"
    break
  fi
done
if [ -d "$HOME/artemis-broker/bin" ]; then
  export PATH="$HOME/artemis-broker/bin:$PATH"
fi

echo "TP Environment Ready:"
java -version
mvn -version
