package bpel.tp.choreography;

import bpel.tp.transport.ActivateRequest;
import bpel.tp.transport.ActivateResponse;
import bpel.tp.transport.TransportServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import java.util.Map;

@SpringBootApplication
@EnableJms
public class TransportEventAdapter {
    public static void main(String[] a) { SpringApplication.run(TransportEventAdapter.class, a); }

    @Bean
    public TransportServiceImpl transportService() { return new TransportServiceImpl(); }
}

// Implementing the transport listener for approved payments
@Component
class TransportListener {
    @Autowired private JmsTemplate jms;
    @Autowired private TransportServiceImpl transport;

    @JmsListener(destination = "PaymentDecided")
    public void onPaymentDecided(String json) throws Exception {
        Event e = Event.parse(json);
        if (e.data.get("approved").asBoolean()) {
            String studentId = e.data.get("studentId").asText();
            ActivateRequest req = new ActivateRequest();
            req.setStudentId(studentId);
            ActivateResponse r = transport.activatePass(req);

            Event out = Event.of("PassActivated", e.correlationId, "transport-service",
                    Map.of("studentId", studentId, "passId", r.getPassId()));
            jms.convertAndSend("EnrollmentCompleted", out.toJson());
        }
    }
}
