package bpel.tp.choreography;

import bpel.tp.university.CancelRequest;
import bpel.tp.university.RegisterRequest;
import bpel.tp.university.RegisterResponse;
import bpel.tp.university.StudentType;
import bpel.tp.university.UniversityServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import java.util.Map;

@SpringBootApplication
@EnableJms
public class UniversityEventAdapter {
    public static void main(String[] a) { SpringApplication.run(UniversityEventAdapter.class, a); }

    @Bean
    public UniversityServiceImpl universityService() { return new UniversityServiceImpl(); }
}

// Implementing the university listener for registration and compensation
@Component
class UniversityListener {
    @Autowired private JmsTemplate jms;
    @Autowired private UniversityServiceImpl university;

    @JmsListener(destination = "EnrollmentRequested")
    public void onEnrollmentRequested(String json) throws Exception {
        Event e = Event.parse(json);
        StudentType st = new StudentType();
        st.setName(e.data.get("student").get("name").asText());
        st.setProgram(e.data.get("student").get("program").asText());
        RegisterRequest req = new RegisterRequest();
        req.setStudent(st);
        RegisterResponse r = university.register(req);

        Event out = Event.of("StudentRegistered", e.correlationId, "university-service",
                Map.of("studentId", r.getStudentId(),
                       "amount", e.data.get("amount").asText()));
        jms.convertAndSend("StudentRegistered", out.toJson());
    }

    @JmsListener(destination = "PaymentDecided")
    public void onPaymentDecided(String json) throws Exception {
        Event e = Event.parse(json);
        if (!e.data.get("approved").asBoolean()) {
            String studentId = e.data.get("studentId").asText();
            CancelRequest req = new CancelRequest();
            req.setStudentId(studentId);
            university.cancel(req);

            Event out = Event.of("EnrollmentCompleted", e.correlationId, "university-service",
                    Map.of("studentId", studentId, "status", "REFUSED"));
            jms.convertAndSend("EnrollmentCompleted", out.toJson());
        }
    }
}
