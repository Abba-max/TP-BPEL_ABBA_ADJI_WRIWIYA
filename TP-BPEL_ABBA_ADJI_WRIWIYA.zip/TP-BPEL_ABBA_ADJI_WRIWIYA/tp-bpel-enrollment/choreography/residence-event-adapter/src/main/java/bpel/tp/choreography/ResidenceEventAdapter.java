package bpel.tp.choreography;

import bpel.tp.residence.AssignRequest;
import bpel.tp.residence.AssignResponse;
import bpel.tp.residence.ResidenceServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import java.util.Map;

@SpringBootApplication
@EnableJms
public class ResidenceEventAdapter {
    public static void main(String[] a) { SpringApplication.run(ResidenceEventAdapter.class, a); }

    @Bean
    public ResidenceServiceImpl residenceService() { return new ResidenceServiceImpl(); }
}

// Implementing the residence listener for approved payments
@Component
class ResidenceListener {
    @Autowired private JmsTemplate jms;
    @Autowired private ResidenceServiceImpl residence;

    @JmsListener(destination = "PaymentDecided")
    public void onPaymentDecided(String json) throws Exception {
        Event e = Event.parse(json);
        if (e.data.get("approved").asBoolean()) {
            String studentId = e.data.get("studentId").asText();
            AssignRequest req = new AssignRequest();
            req.setStudentId(studentId);
            AssignResponse r = residence.assignRoom(req);

            Event out = Event.of("RoomAssigned", e.correlationId, "residence-service",
                    Map.of("studentId", studentId, "roomNumber", r.getRoomNumber()));
            jms.convertAndSend("EnrollmentCompleted", out.toJson());
        }
    }
}
