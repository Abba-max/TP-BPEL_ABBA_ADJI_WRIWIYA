package bpel.tp.choreography;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

// Here, I am setting up the common JSON event envelope shared across all choreography adapters
public class Event {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public String eventId;
    public String correlationId;
    public String timestamp;
    public String source;
    public String type;
    public JsonNode data;

    public static Event parse(String json) throws Exception {
        return MAPPER.readValue(json, Event.class);
    }

    public static Event of(String type, String correlationId, String source, Map<String, Object> data) {
        Event e = new Event();
        e.eventId = UUID.randomUUID().toString();
        e.correlationId = correlationId;
        e.timestamp = Instant.now().toString();
        e.source = source;
        e.type = type;
        e.data = MAPPER.valueToTree(data);
        return e;
    }

    public String toJson() throws Exception {
        return MAPPER.writeValueAsString(this);
    }
}
