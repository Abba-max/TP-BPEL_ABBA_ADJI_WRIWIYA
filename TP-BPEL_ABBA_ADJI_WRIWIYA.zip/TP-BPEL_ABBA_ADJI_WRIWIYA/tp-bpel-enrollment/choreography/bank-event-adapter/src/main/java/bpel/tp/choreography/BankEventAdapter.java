package bpel.tp.choreography;

import bpel.tp.bank.BankServiceImpl;
import bpel.tp.bank.PayRequest;
import bpel.tp.bank.PayResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.Map;

@SpringBootApplication
@EnableJms
public class BankEventAdapter {
    public static void main(String[] a) { SpringApplication.run(BankEventAdapter.class, a); }

    @Bean
    public BankServiceImpl bankService() { return new BankServiceImpl(); }
}

// Implementing the bank listener from the TP specification
@Component
class BankListener {
    @Autowired private JmsTemplate jms;
    @Autowired private BankServiceImpl bank;

    @JmsListener(destination = "StudentRegistered")
    public void onStudentRegistered(String json) throws Exception {
        Event e = Event.parse(json);
        PayRequest req = new PayRequest();
        req.setStudentId(e.data.get("studentId").asText());
        req.setAmount(new BigDecimal(e.data.get("amount").asText()));
        PayResponse r = bank.pay(req);

        Event out = Event.of("PaymentDecided", e.correlationId, "bank-service",
                Map.of("studentId", e.data.get("studentId").asText(),
                       "approved", r.isApproved(),
                       "receipt", r.getReceipt()));
        jms.convertAndSend("PaymentDecided", out.toJson());
    }
}
